my $foo = 'bar';


